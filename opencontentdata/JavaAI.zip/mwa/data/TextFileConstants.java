// TextFileConstants.java

package mwa.data;

public interface TextFileConstants {
  public static final float NAN = -9999.9182f;
}
