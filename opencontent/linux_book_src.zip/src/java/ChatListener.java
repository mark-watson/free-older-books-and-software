// File: ChatListener.java
//
// Defines the ChatLister interface
//

public interface ChatListener {
  public void receiveText(String s);
}
